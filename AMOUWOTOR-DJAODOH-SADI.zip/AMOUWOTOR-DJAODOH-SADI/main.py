from argumental import *

if __name__ == "__main__":
	SolverManager.get_instance().solve()
